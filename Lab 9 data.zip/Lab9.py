import shelve   
def exclquestionfile():
    print('\n\n\nThis program takes a file with only exclamation and question sentences, replaces all "!" with "#" in the original file, writes all question sentences and their quantity to the new file')
    name=input('Enter the filename: ')
    middest=name.split('\\')
    dest=''
    for i in range(len(middest)-1):
        dest+=middest[i]+'\\'
    dest+='result.txt'
    with open(name,'r') as fbeg:
        print('Base text: ',fbeg.read())
        input ('Press ENTER to continue')
        fin=''
        fbeg.seek(0)
        for sym in str(fbeg.read()):
            if sym=='!':
                fin+='#'
            else:
                fin+=sym
    print ('\nStep 1. All "!" are replaced with "#": ', fin, '\nAll changes are saved to ',name)
    with open(name, 'w') as fbeg:
        fbeg.write(fin)
    input ('Press ENTER to continue')
    fin=fin.replace('\n', ' ')
    with open(dest, 'w') as result:
        el=''
        count=0
        truefin=""
        for sym in fin:
            el+=sym
            if sym=='?':
                truefin+=el
                el=''
                count+=1
            elif sym=='#':
                el=''
        truefin=truefin[1:]+'\nQuestion sentences: '+ str(count)
        result.write(truefin)
        print ('\nStep 2. All question sentences and their quantity: ', truefin, '\n\nAll changes are saved to the file "result.txt"')
        input('Press ENTER to continue')
def a(file,action):                            #Task A (Lab 8)
    print("\n\n\nThis program creates a dictionary. Every element contains next info: Student's surname, if he studies on government cost or on a contract (G/C), his average mark, and education cost (None if on government cost).") 
    stud=file['stud']
    stud=generatorOne(stud)
    while True:
        print("\n\n\n1. Sum of contract cost of all students") 
        print("2. Show excellent students (average mark is 5), and change their education form on 'On Government cost'") 
        print("3. Exclude students whose average mark is below 2.5")
        print("4. Output current student dictionary")
        print("5. Show action results")
        print("6. Add students to the list")
        print("7. Quit to the previous menu")
        choice=input("Input action: ")
        if choice=="1":
            contractsum(stud,action)
        elif choice=="2":
            stud=excelstud(stud,action) 
        elif choice=="3":
            stud=studexcl(stud)
        elif choice=="4":
            dictout(stud)
        elif choice=="5":
            actout(action)
        elif choice=="6":
            stud=addstud(stud)
        elif choice=="7":
            break
        else:
            print("Invalid item.")
    file['stud']=stud
    action.sync()
    file.sync()
def generatorOne(test, i=1, new=True):  #List Dictionary generator for Task A
    if new==True:
        yn=input("Do you want to INPUT a dictionary or use a PREVIOUS one? I/P: ")
        while yn!="I" and yn!="P":
            print('Please input only I or P')
            yn=input("Do you want to INPUT a dictionary or use a PREVIOUS one? I/P: ")      
        if yn=="P":
            return test
    print("\nYou've entered an input mode. For each student input asked info. If you want to finish working with input, enter nothing on any of steps, you'll be asked if you want to quit (All unsaved data will be erased).\n")
    fin={}
    while True:
        print("Student №",i)
        emp="N"
        name=paym=mark=cost=""
        while name=="":
            name=input("Please enter student's surname: ")
            emp=checkifempty(name)
            if emp=="Y":
                return fin
            else:
                continue
        while paym=="" and emp=="N":
            paym=input("Please enter if the student studies on a GOVERNMENT cost or is he on a CONTRACT (G/C): ")
            while paym!="G" and paym!="C" or paym.isspace==False:
                print('Please input only G or C')
                paym=input("Please enter if the student studies on a GOVERNMENT cost or is he on a CONTRACT (G/C): ")
            emp=checkifempty(paym)
            if emp=="Y":
                return fin
        while mark=="" and emp=="N":
            premark=input("Please enter student's average mark: ")
            emp=checkifempty(premark)
            if emp=="Y":
                return fin
            try:
                mark=float(premark)
            except:
                print("Input value MUST be a number")
                mark=""
        if paym=="C":
            while cost=="" and emp=="N":
                precost=input("Please enter students education cost: ")
                emp=checkifempty(precost)
                if emp=="Y":
                    return fin
                try:
                    cost=float(precost)
                except:
                    print("Input value MUST be a number")
                    cost=""    
        else:
            cost="None"
        fin[i]=[name,paym,mark,cost]
        i+=1
def checkifempty(elem):                 #Checks if the user wants to finish entering elements to the list
    if elem=="":
        while True:
            yn=input("Do you want to finish entering elements to the list? Y/N ")
            if yn!="Y" and yn!="N":
                print('Please input only Y or N')
            else:
                break
    else:
        yn="N" 
    return yn
def contractsum(di,action):             #Sum of contract cost of all students
    sum=0
    for i in di.values():
        try:
            if i[1]=="C":
                sum+=i[3]
        except:
            continue
    action['contractsum']="The sum of all contract costs equals: "+str(sum)
    print (action['contractsum'])
    input("Press ENTER to continue") 
def excelstud(di,action):               #Show excellent students, and change their education form on 'On Government cost'
    superpuper="Excellent students: "
    for n in di:
        i=di[n]
        if i[2]==5:
            superpuper+=i[0]+", "
            i[1]="G"
            i[3]="None"
            di.update({n:i})
    action['excelstud']=superpuper[:-2]
    print(action['excelstud'])
    input ('Press ENTER to continue')
    return di
def studexcl(di):                       #Exclude students whose average mark is below 2.5
    ind=[]
    for n in di:
        ind.append(n)
    for n in ind:
        if di[n][2]<2.5:
            di.pop(n)
    return di
def dictout(di):                        #Output current student dictionary
    print(" "*18,"Student Ed.Form Av.Mark Ed.Cost\n","="*100)
    for el in di:
        print ("%25s     %s       %d    %s"%(di[el][0],di[el][1],di[el][2],di[el][3]))
    input ('Press ENTER to continue')
def actout(action):
    print('')
    try:
        print(action['contractsum'])
    except:
        print('No contract sum action completed')
    try:
        print(action['excelstud'])
    except:
        print('No excellent students action completed')
    input('Press ENTER to continue')
def addstud(list):
    i=max(list)+1
    add=generatorOne({},i,False)
    list.update(add)
    return list
def b(file):                                #Task B (Lab 8)
    print("This program analyses the given lists of computers in colleges from the dictionary and compares them to the list of all possible computer types there")
    comps=file['comps']
    coleges=file['coleges']
    netu=[]
    est=[]
    yn=input("Do you want to INPUT a list and a dictionary or use a PREVIOUS one? I/P: ")
    while yn!="I" and yn!="P":
        print('Please input only I or P')
        yn=input("Do you want to INPUT a list and a dictionary or use a PREVIOUS one? I/P: ")      
    if yn=="I":
        print("You've entered the input mode. First, enter all the types of computers that can exist in colleges")
        comps=generatorTwoP1()
        print("\nFor college input computer list. If you want to finish working with input, enter nothing on any of steps, you'll be asked if you want to quit.\n")
        coleges=generatorTwoP2(comps)
        print("\n\n")
    for comp in comps:
        count=0
        for col in coleges:
            if (comp in col)==True:
                count+=1
        if count>=3:
            est.append(comp)
        elif count==0:
            netu.append(comp)
        fin_est="Present in at least 3 colleges: "
        fin_netu="\nAbsent in all of colleges: "
        for k in est:
            fin_est+=k+", "
        for k in netu:
            fin_netu+=k+", "
    print(fin_est[:-2],fin_netu[:-2])
    file['comps']=comps
    file['coleges']=coleges
    file.sync
    input("Press ENTER to quit to the T2 Menu")
def generatorTwoP1(ifnew=True,inp={}):      #List generator for Task B
    comps=set()
    while True:
        el=""
        while el=="":
            el=input("Please enter computer type: ")
            emp=checkifempty(el)
            if emp=="Y":     
                return comps 
            else:
                if ifnew==False and (el in inp)==False:
                    print ("Element is absent in original list")
                    el=""
                else:
                    comps.add(el)            
def generatorTwoP2(inp):                    #List dictionary generator for Task B
    fin=[]
    i=1
    while True:
        print("College №",i)
        fin.append(generatorTwoP1(False, inp))
        i+=1
        while True:
            yn=input("Continue? Y/N ")
            if yn!="Y" and yn!="N":
                print('Please input only Y or N')
            else:
                break
        if yn=="N":
            break
    return fin
def lab8edited():
    name=input('Enter the destination to the data: ')
    data=name + 'lab9data'
    file=shelve.open(data)
    act=name + 'actions'
    while True:
        print ("\n\n\nTask B Menu\n\nSubTask a: Student Dictionary\nSubTask b: Computers in Colleges Dictionary\nQ: Quit to the previous menu")
        choice=input("Choose an item: ")
        if choice=="a":
            action=shelve.open(act)
            a(file,action)
            action.close()
        elif choice=="b":
            b(file)
        elif choice=="Q":
            break       
        else:
            print("Invalid item")
    file.close()
def mainmenu():
    while True:
        print('\n\n\nLaboratory Work №9\n Main menu\n\nTask A: Exclamation and Question Sentences\nTask B: Dictionary Processing\nC: About the author\nQ: Quit the program')
        choice=input("Choose an item: ")
        if choice=="A":
            exclquestionfile()
        elif choice=='B':
            lab8edited()
        elif choice=="C":
            print ('\nAbout:\nLaboratory Work №9 \nMade by Kholyavkin Ivan VAR 21 \nGroup IPZ-11')
            input("Press ENTER to continue")
        elif choice=='Q':
            break
        else:
            print("Invalid item")

mainmenu()